﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Entities;
using DataAccess;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows.Media;

namespace Storage
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private DatabaseHandler databaseHandler; 

        public MainWindow()
        {
            InitializeComponent();
            databaseHandler = new DatabaseHandler();
            FillDataGrid();
            txbItemName.IsEnabled = false;
            txbAmount.IsEnabled = false;
            txbTotal.IsEnabled = false;
        }

        private void FillDataGrid()
        {
            List<Item> showItems = databaseHandler.GetAllItems();
            dtgItems.ItemsSource = showItems;
        }

        #region Renaming columns and fixed width
        //Renaming columns in the datagrid and fixing the width
        private void DataGrid_OnAutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.Column.Header.ToString() == "ItemName")
            {
                e.Column.Header = "Produkt";
                e.Column.Width = 400;
            }

            if (e.Column.Header.ToString() == "Produkt")
            {
                e.Column.Width = 400;
            }

            if (e.Column.Header.ToString() == "Amount")
            {
                e.Column.Header = "På lager";
            }

            if (e.Column.Header.ToString() == "TotalAmount")
            {
                e.Column.Header = "I alt";
            }
        }
        #endregion

        //If text ix changed, add any item to a new list, that contains the typed. Return list of items that match.
        private void txbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string searchText = txbSearch.Text;

            if (txbSearch.Text != "")
            {
                List<Item> resultList = new List<Item>();
                List<Item> searchList = dtgItems.ItemsSource as List<Item>;

                foreach (Item item in searchList)
                {
                    if (item.ItemName.IndexOf(searchText, 0, StringComparison.CurrentCultureIgnoreCase) != -1)
                    {
                        resultList.Add(item);
                    }
                }

                dtgItems.ItemsSource = resultList;
            }
        }

        //If the search string is empty and backspace is pressed, return full list
        private void txbSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txbSearch.Text) && e.Key == Key.Back)
            {
                FillDataGrid();
            }
        }

        //Getting the selected item and displaying the values, in order to edit/delete the item
        private void dtgItems_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Item selected = dtgItems.SelectedItem as Item;
            
            if (dtgItems.SelectedIndex != -1)
            {
                txbItemName.Text = selected.ItemName;
                txbAmount.Text = selected.Amount.ToString();
                txbTotal.Text = selected.TotalAmount.ToString();
                txbAmount.IsEnabled = true;
                txbItemName.IsEnabled = true;
                txbTotal.IsEnabled = true;
            }            

            if (dtgItems.SelectedIndex <= -1)
            {
                txbItemName.Clear();
                txbAmount.Clear();
                txbTotal.Clear();
                txbAmount.IsEnabled = false;
                txbItemName.IsEnabled = false;
                txbTotal.IsEnabled = false;
            }            
        }

        #region Update item
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            bool validation = false;
            string value = txbAmount.Text;
            decimal number;

            if (!Decimal.TryParse(value, out number))
            {
                validation = false;
                lblUpdate.Content = "Kun tilladt at indtaste tal.";
                lblUpdate.Foreground = Brushes.Red;
            }
            else
            {
                validation = true;
                lblUpdate.Content = "";
            }

            try
            {
                Item selected = dtgItems.SelectedItem as Item;

                if (selected == null || string.IsNullOrWhiteSpace(txbItemName.Text))
                {
                    lblUpdate.Content = "Vælg venligst et produkt.";
                    lblUpdate.Foreground = Brushes.Red;
                }

                if (selected != null && !string.IsNullOrWhiteSpace(txbItemName.Text) && validation)
                {
                    lblUpdate.Content = "";
                    databaseHandler.UpdateItem(selected, txbItemName.Text, Int32.Parse(txbAmount.Text), Int32.Parse(txbTotal.Text));
                    FillDataGrid();
                    txbItemName.Text = "";
                    txbAmount.Text = "";
                    txbAmount.IsEnabled = false;
                    txbItemName.IsEnabled = false;
                }
            }
            catch (Exception ex) { lblUpdate.Content = "Fejl: " + ex.Message; }
        }
        #endregion

        #region Add item
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            bool validation = false;
            string value = txbAddAmount.Text;
            decimal number;

            string value2 = txbAddTotal.Text;
            decimal number2;

            List<Item> duplicates = databaseHandler.Duplicate(txbAddItemName.Text);

            if (Decimal.TryParse(value, out number))
            {
                validation = true;
                lblUpdate.Content = "";
                lblAddError.Foreground = Brushes.Gray;
            }

            if (Decimal.TryParse(value2, out number2))
            {
                validation = true;
                lblUpdate.Content = "";
                lblAddError.Foreground = Brushes.Gray;
            }

            if (!string.IsNullOrWhiteSpace(txbAddItemName.Text))
            {
                validation = true;
                lblAddError.Content = "";
                lblAddError.Foreground = Brushes.Gray;
            }

            if (duplicates.Count == 0)
            {
                validation = true;
            }

            if (duplicates.Count >= 1)
            {
                validation = false;
                lblAddError.Content = "Dette produktnavn er allerede i brug.";
                lblAddError.Foreground = Brushes.Red;
            }

            if (!Decimal.TryParse(value2, out number2))
            {
                validation = false;
                lblAddError.Content = "Indtast et tal(antal).";
                lblAddError.Foreground = Brushes.Red;
            }

            if (!Decimal.TryParse(value, out number))
            {
                validation = false;
                lblAddError.Content = "Indtast et tal(antal).";
                lblAddError.Foreground = Brushes.Red;
            }

            if (string.IsNullOrWhiteSpace(txbAddItemName.Text))
            {
                validation = false;
                lblAddError.Content = "Indtast et produktnavn";
                lblAddError.Foreground = Brushes.Red;
            }


            if (!string.IsNullOrWhiteSpace(txbAddItemName.Text) && validation)
            {
                try
                {
                    Item newItem = new Item(txbAddItemName.Text, Int32.Parse(txbAddAmount.Text), Int32.Parse(txbAddTotal.Text));

                    databaseHandler.AddItem(newItem);
                    FillDataGrid();
                    txbAddItemName.Clear();
                    txbAddAmount.Clear();
                    txbAddTotal.Clear();
                }
                catch (Exception ex) { lblAddError.Content = "Fejl: " + ex.Message; }
            }
        }
        #endregion

        #region Delete item
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Item selected = dtgItems.SelectedItem as Item;

            if (selected != null)
            {
                try
                {
                    databaseHandler.Delete(selected);
                    FillDataGrid();
                    txbItemName.Clear();
                    txbAmount.Clear();
                }
                catch (Exception ex) { MessageBox.Show("Der er sket en fejl: " + ex.Message); }
            }
        }

        #endregion

    }
}
