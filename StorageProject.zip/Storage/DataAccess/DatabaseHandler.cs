﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entities;

namespace DataAccess
{
    #region Connection
    public class DatabaseHandler
    {
        /// <summary>
        /// The connection string. Data Source is the server name. Initial Catalog is the database name.
        /// </summary>
        private readonly string connectionString = @"Data Source=(LocalDb)\MSSQLLocalDB;" + // The datasource is the SQL Server instance on your computer. (LocalDb)\MSSQLLocalDB is the server name - used when you attempt to connect to a server in SQL Server Management Studio.
                                                @"Initial Catalog=StorageDB;" +           // The name of the database. This is also called an Initial Catalog
                                                @"Integrated Security=true;";           // Always leave it at true.

        /// <summary>
        /// Creates an instance of this class, and performs a check to see if there is a connection to the DB. 
        /// Throws exception otherwise.
        /// </summary>
        public DatabaseHandler()
        {
            // Encapsulate in try-catch. Just re-throw any exception that have been thrown:
            try
            {
                // Encapsulate the communication with the DB in a using block, to manage resources:
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Try to open the connection:
                    connection.Open();

                    /* If the connection is not established, an exception will be thrown here.
                    * Then it will be caught in the catch block below. 
                    * The catch block will simply re-throw the exception, to whatever method called -
                    * usually a method in th UI. There it will be handled by showing the user a message box.
                    */

                    // Try to close the connection:
                    connection.Close();
                }// end SqlConnection using block.
            }// end try block.
            catch (Exception)
            {
                // Re-throw any caught exception:
                throw;
            }// end catch block.
        }// end method.
        #endregion Connection

        #region Get all items
        public List<Item> GetAllItems()
        {
            // Create the empty list of cars, that will be returned, after all cars from db have been added:
            List<Item> itemsFromDB = new List<Item>();

            // Create the string with the SQL query:
            string sqlQuery = "SELECT * FROM Items";

            // Encapsulate in try-catch. Just re-throw any exception that have been thrown:
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sqlQuery, connection);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Get the number of each column and save it to a variable:
                        int columnNumberOfItemColumn = reader.GetOrdinal("Item");
                        int columnNumberOfAmountColumn = reader.GetOrdinal("Amount");
                        int columnNumberOfTotalAmountColumn = reader.GetOrdinal("TotalAmount");

                        // While there is still rows in the table:
                        while (reader.Read())
                        {
                            // Save value of each cell to a variable:
                            string itemName = reader.GetString(columnNumberOfItemColumn);
                            int amount = (int)reader.GetInt32(columnNumberOfAmountColumn);
                            int totalAmount = (int)reader.GetInt32(columnNumberOfTotalAmountColumn);


                            // Create a new Car object, with values the values from the row:
                            Item ItemsRowFromDB = new Item(itemName, amount, totalAmount);

                            // Add the car object to the list:
                            itemsFromDB.Add(ItemsRowFromDB);
                        }// end while loop.
                    }// end SqlDataReader using block.

                    connection.Close();
                }// end SqlConnection using block.
            }// end try block.
            catch (Exception)
            {
                // Re-throw any caught exception:
                throw;
            }// end catch block.
           
            // Return the list of cars:
            return itemsFromDB;
        }// end method.
        #endregion

        #region Update item
        public void UpdateItem(Item item, string newItemName, int newAmount, int newTotalAmount)
        {
            string sqlQuery = $"UPDATE Items SET Amount = '{newAmount}', Item = '{newItemName}', TotalAmount = '{newTotalAmount}' WHERE Item = '{item.ItemName}'";
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sqlQuery, connection);
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

        #region Add item
        public void AddItem(Item newItem)
        {
            // Encapsulate in try-catch. Just re-throw any exception that have been thrown:
            try
            {
                // Encapsulate the communication with the DB in a using block, to manage resources:
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Try to open the connection. If it fails an exception will be thrown:
                    connection.Open();

                    // Create the SQL query string (the @ is a smart way to use words in the string as column names):
                    string sqlQuery = "INSERT INTO Items(Item, Amount, TotalAmount) Values(@Item, @Amount, @TotalAmount)";

                    // An SqlCommand actually performs the query, but first it must be created:
                    SqlCommand command = new SqlCommand(sqlQuery, connection);

                    // Add each column as 'parameters' to the command:
                    command.Parameters.Add("@Item", SqlDbType.NVarChar, 75);
                    command.Parameters.Add("@Amount", SqlDbType.Int);
                    command.Parameters.Add("@TotalAmount", SqlDbType.Int);


                    // Each parameter can hold a value (like a variable). 
                    // These values are the values in the fields of the car object.
                    // We use the properties of the car object, to get these values and then assign 
                    // them to the 'parameters' (behaves like fields) of the command object:
                    command.Parameters["@Item"].Value = newItem.ItemName;
                    command.Parameters["@Amount"].Value = newItem.Amount;
                    command.Parameters["@TotalAmount"].Value = newItem.TotalAmount;

                    // Execute the query. If it fails it will throw an exception:
                    command.ExecuteNonQuery();

                    // Finally close the connection:
                    connection.Close();
                }// end SqlConnection using block.
            }// end try block.
            catch (Exception)
            {
                // Re-throw any caught exception:
                throw;
            }// end catch block.
        }// end method.
        #endregion

        #region Delete item
        public void Delete(Item item)
        {
            string sqlQuery = $"DELETE FROM Items WHERE Item = '{item.ItemName}' AND Amount = '{item.Amount}'";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sqlQuery, connection);
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Check for already exisiting item
        public List<Item> Duplicate(string duplicateItem)
        {
            // Create the empty list of cars, that will be returned, after all cars from db have been added:
            List<Item> itemsFromDB = new List<Item>();

            // Create the string with the SQL query:
            string sqlQuery = $"SELECT * FROM Items WHERE Item = '{duplicateItem}'";

            // Encapsulate in try-catch. Just re-throw any exception that have been thrown:
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sqlQuery, connection);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Get the number of each column and save it to a variable:
                        int columnNumberOfItemColumn = reader.GetOrdinal("Item");
                        int columnNumberOfAmountColumn = reader.GetOrdinal("Amount");
                        int columnNumberOfTotalAmountColumn = reader.GetOrdinal("TotalAmount");

                        // While there is still rows in the table:
                        while (reader.Read())
                        {
                            // Save value of each cell to a variable:
                            string itemName = reader.GetString(columnNumberOfItemColumn);
                            int amount = (int)reader.GetInt32(columnNumberOfAmountColumn);
                            int totalAmount = (int)reader.GetInt32(columnNumberOfTotalAmountColumn);


                            // Create a new Car object, with values the values from the row:
                            Item ItemsRowFromDB = new Item(itemName, amount, totalAmount);

                            // Add the car object to the list:
                            itemsFromDB.Add(ItemsRowFromDB);
                        }// end while loop.
                    }// end SqlDataReader using block.

                    connection.Close();
                }// end SqlConnection using block.
            }// end try block.
            catch (Exception)
            {
                // Re-throw any caught exception:
                throw;
            }// end catch block.

            // Return the list of cars:
            return itemsFromDB;
        }// end method.
        #endregion
    }

}
