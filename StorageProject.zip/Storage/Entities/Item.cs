﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Item
    {
        public string ItemName { get; set; }
        public int Amount { get; set; }
        public int TotalAmount { get; set; }

        public Item(string itemName, int amount, int totalAmount)
        {
            ItemName = itemName;
            Amount = amount;
            TotalAmount = totalAmount;
        }

        public override string ToString()
        {
            return ItemName + Amount + TotalAmount;
        }
    }
}
